import numpy as np
from pandas import read_csv
from pandas.plotting import scatter_matrix
import pandas as pd
from matplotlib import pyplot
from sklearn.model_selection import train_test_split
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.preprocessing import MinMaxScaler

#training dataset
#url = "https://raw.githubusercontent.com/cctech-labs/challenges/master/2020/06/hiring/resources/data_science/challenge2_dataset.csv"
dataset = read_csv("1.csv")
print(dataset.shape)
#Cleaning the dataset
print(dataset.isnull().sum())
dataset.dropna(inplace=True)
print(dataset.shape)
X = dataset[['1', '2', '3']].values
Y = dataset[['Target']].values
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.20, random_state=0)

#convert all data types to float
dataset=X.astype(float)

#applying scaling
scaler = MinMaxScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.fit_transform(X_test)
#print(X.head(20))
#print(X_train)
#print(Y_train)
#KNN
modelk = KNeighborsClassifier()
#np.where(X_train.values >= np.finfo(np.float64).max)
modelk.fit(X_train,np.ravel(Y_train))
predictions = modelk.predict(X_test)
print(accuracy_score(Y_test,predictions))
dataset = read_csv("2.csv")
dataset.dropna(inplace=True)
A=dataset[['1', '2', '3']].values
A = scaler.fit_transform(A)
predictions = modelk.predict(A)


#SVC
models = SVC()
models.fit(X_train,np.ravel(Y_train))
predictions = models.predict(X_test)
print(accuracy_score(Y_test,predictions))
#dataset = read_csv("2.csv")
#dataset.dropna(inplace=True)
#A=dataset[['1', '2', '3']].values
#A = scaler.fit_transform(A)
predictions = models.predict(A)
#print(predictions)



#RandomForest (Giving the highest accuracy)
modelr = RandomForestClassifier(n_estimators=100)
modelr.fit(X_train,np.ravel(Y_train))
predictions = modelr.predict(X_test)
#print(predictions)
print(accuracy_score(Y_test,predictions))
#url = "https://raw.githubusercontent.com/cctech-labs/challenges/master/2020/06/hiring/resources/data_science/challenge2_dataset.csv"
#dataset = pd.read_csv("2.csv")
#dataset.dropna(inplace=True)
#A=dataset[['1', '2', '3']].values
predictions = modelr.predict(A)
predictions=pd.DataFrame({'Predicted': predictions})
print(predictions)
A=pd.DataFrame(A)
print(A)
A.to_csv('modified.csv')
predictions.to_csv('prediction.csv')


#LogisticRegression
modell = LogisticRegression()
modell.fit(X_train,np.ravel(Y_train))
predictions = modell.predict(X_test)
print(accuracy_score(Y_test,predictions))
#dataset = read_csv("2.csv")
#dataset.dropna(inplace=True)
#A=dataset[['1', '2', '3']].values
predictions = modell.predict(A)
#print(predictions)

