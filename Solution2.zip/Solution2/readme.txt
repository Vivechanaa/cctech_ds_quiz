Solution2.py:           file has been written python3.x
	                The solution was run on 4-classifier KNN, SVC,RandomForest,LogisticRegression and final classifier choosen was RandomForest (maximum accuracy)
1.csv:                  containg the training data-point (modified: true /false-> 1/0 )
2.csv:                  is the data point for prediction
modified-prediction:    contain the data after cleaning (scaled data and removed missing entries)
                        FinalSolution2 contain the final solution (missing values has been removed from the final output)