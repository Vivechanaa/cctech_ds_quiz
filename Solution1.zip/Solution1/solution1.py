import pandas as pd  
import numpy as np  
import matplotlib.pyplot as plt  
import seaborn as seabornInstance
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn import metrics
from sklearn.metrics import mean_squared_error#, r2_Score
#%matplotlib inline
url='https://raw.githubusercontent.com/cctech-labs/challenges/master/2020/06/hiring/resources/data_science/dataset.csv'
dataset = pd.read_csv(url)
X = dataset[['0', '1', '2', '3', '4', '5', '6', '7', '8']].values
y = dataset['target'].values
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)
regressor = LinearRegression()  
regressor.fit(X_train, y_train)
y_pred = regressor.predict(X_test)
test_set_rmse = (np.sqrt(mean_squared_error(y_test, y_pred)))

test_set_r2 = metrics.r2_score(y_test, y_pred)

print(test_set_rmse)
print(test_set_r2)
accuracy = regressor.score(X_test,y_test)
print(accuracy*100,'%')

#prediction dataset
path='https://raw.githubusercontent.com/cctech-labs/challenges/master/2020/06/hiring/resources/data_science/prediction.csv'
data = pd.read_csv(path)
A = data[['0', '1', '2', '3', '4', '5', '6', '7', '8']].values
p_pred = regressor.predict(A)
df = pd.DataFrame({'Predicted': p_pred})
df1 = df.head()
